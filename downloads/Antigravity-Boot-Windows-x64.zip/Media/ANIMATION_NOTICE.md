# 随附角色动画使用说明

本说明适用于以下五段完整 MP4，包括文件内随附的音轨。

| 动画 | 仓库文件 |
| --- | --- |
| 经典版 | `Media/Presets/gemini-classic.mp4` |
| 水彩绘本 | `Media/Presets/gemini-watercolor.mp4` |
| 霓虹都市 | `Media/Presets/gemini-neon.mp4` |
| 换班 | `Media/Presets/gemini-switch-team.mp4` |
| 星门回眸 | `Media/Presets/gemini-stargate.mp4` |

五段动画仅随 Antigravity Boot 提供，用于个人非商业播放、体验及本项目的非商业演示。分享包含这些动画的完整项目或安装包时，请保留本说明。

随包的「星门回眸」为 10 秒静音版。

**五段动画不开源，不适用项目代码的 MIT 许可证，禁止商业使用。** 商业使用包括出售动画、将其打包到付费产品、用于商业广告或付费推广。

对于单独提取角色、画面或音轨并用于其他作品，或将其收录、分发为独立素材包，请另行取得相关权利人的许可。视频中涉及的角色设计、标志和其他第三方素材，其权利归各自权利人。
